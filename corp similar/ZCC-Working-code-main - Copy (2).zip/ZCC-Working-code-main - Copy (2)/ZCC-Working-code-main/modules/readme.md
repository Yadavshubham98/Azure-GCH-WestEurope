Module for Base_cc_LB
